from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="CM Compta OHADA PRO")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"]
)

sales = []
stock = []

@app.get("/")
def home():
    return {"status": "CM Compta OHADA PRO ONLINE"}

@app.get("/sales")
def get_sales():
    return sales

@app.post("/sales")
def add_sale(data: dict):
    sales.append(data)
    return {"message": "vente ajoutée"}

@app.get("/stock")
def get_stock():
    return stock

@app.post("/stock")
def add_stock(data: dict):
    stock.append(data)
    return {"message": "stock ajouté"}
